#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RichyScript Interpreter v2.0
Complete language interpreter with:
- Lists [1, 2, 3]
- For loops (range + each)
- Operators += -= *= /=
- Comments /* */
- Functions *args
- RichCollection
"""

import sys
import os
import random
import re
import tkinter.messagebox as tkmb
import tkinter.simpledialog as tksd
import tkinter.filedialog as tkfd
import tkinter.colorchooser as tkcc
from tkinter import *

from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *


__version__ = "2.1.0"

# ============================================================
# TOKEN
# ============================================================
class Token:
    def __init__(self, type_, value, line):
        self.type = type_
        self.value = value
        self.line = line
    def __repr__(self):
        return f"Token({self.type}, {repr(self.value)}, line={self.line})"

# ============================================================
# LEXER
# ============================================================
class Lexer:
    def __init__(self, code):
        self.code = code
        self.pos = 0
        self.line = 1

    def peek(self): return self.code[self.pos] if self.pos < len(self.code) else ''
    def advance(self): ch = self.peek(); self.pos += 1; return ch

    def skip_whitespace(self):
        while self.peek() in ' \t': self.advance()

    def tokenize(self):
        tokens = []
        while self.pos < len(self.code):
            self.skip_whitespace()
            if self.pos >= len(self.code): break
            ch = self.peek()

            # -- comment
            if ch == '-' and self.pos+1 < len(self.code) and self.code[self.pos+1] == '-':
                while self.peek() != '\n' and self.pos < len(self.code): self.advance()
                if self.peek() == '\n': self.line += 1; self.advance()
                continue

            # /* comment */
            if ch == '/' and self.pos+1 < len(self.code) and self.code[self.pos+1] == '*':
                self.advance(); self.advance()
                while self.pos < len(self.code):
                    if self.peek() == '*' and self.pos+1 < len(self.code) and self.code[self.pos+1] == '/':
                        self.advance(); self.advance(); break
                    if self.peek() == '\n': self.line += 1
                    self.advance()
                continue

            # Numbers
            if ch.isdigit():
                num = ''
                while self.peek().isdigit(): num += self.advance()
                if self.peek() == '.':
                    num += self.advance()
                    while self.peek().isdigit(): num += self.advance()
                tokens.append(Token('NUMBER', float(num), self.line))
                continue

            # Identifiers / Keywords
            if ch.isalpha() or ch == '_':
                ident = ''
                while self.peek().isalnum() or self.peek() == '_': ident += self.advance()
                keywords = {
                    'set':'SET','let':'LET','say':'SAY','ask':'ASK','if':'IF','then':'THEN',
                    'else':'ELSE','end':'END','repeat':'REPEAT','times':'TIMES','while':'WHILE',
                    'do':'DO','for':'FOR','each':'EACH','in':'IN','to':'TO','step':'STEP',
                    'when':'WHEN','random':'RANDOM','number':'NUMBERTYPE','between':'BETWEEN',
                    'and':'AND','true':'TRUE','false':'FALSE','not':'NOT','stop':'STOP',
                    'everything':'EVERYTHING','show':'SHOW','flash':'FLASH','alert':'ALERT',
                    'error':'ERROR','warning':'WARNING','confirm':'CONFIRM','prompt':'PROMPT',
                    'learn':'LEARN','loop':'LOOP','return':'RETURN','module':'MODULE', "assert":'ASSERT'
                }
                token_type = keywords.get(ident, 'IDENTIFIER')
                if ident in ('true','false'): tokens.append(Token('BOOLEAN', ident=='true', self.line))
                else: tokens.append(Token(token_type, ident, self.line))
                continue

            # Strings
            if ch == '"':
                self.advance(); string = ''
                while self.peek() != '"' and self.pos < len(self.code):
                    if self.peek() == '\n': self.line += 1
                    string += self.advance()
                if self.peek() == '"': self.advance()
                else: raise SyntaxError(f"Unclosed string at line {self.line}")
                tokens.append(Token('STRING', string, self.line))
                continue

            # Operators (including +=, -=, *=, /=)
            if ch in '=<>!+-*/[].,':
                op = ch; self.advance()
                if op == '=' and self.peek() == '=': self.advance(); tokens.append(Token('EQEQ','==',self.line))
                elif op == '!' and self.peek() == '=': self.advance(); tokens.append(Token('NOTEQ','!=',self.line))
                elif op == '<' and self.peek() == '=': self.advance(); tokens.append(Token('LTEQ','<=',self.line))
                elif op == '>' and self.peek() == '=': self.advance(); tokens.append(Token('GTEQ','>=',self.line))
                elif op == '+' and self.peek() == '=': self.advance(); tokens.append(Token('PLUSEQ','+=',self.line))
                elif op == '-' and self.peek() == '=': self.advance(); tokens.append(Token('MINUSEQ','-=',self.line))
                elif op == '*' and self.peek() == '=': self.advance(); tokens.append(Token('MULEQ','*=',self.line))
                elif op == '/' and self.peek() == '=': self.advance(); tokens.append(Token('DIVEQ','/=',self.line))
                elif op == '<': tokens.append(Token('LT','<',self.line))
                elif op == '>': tokens.append(Token('GT','>',self.line))
                elif op == '+': tokens.append(Token('PLUS','+',self.line))
                elif op == '-': tokens.append(Token('MINUS','-',self.line))
                elif op == '*': tokens.append(Token('MUL','*',self.line))
                elif op == '/': tokens.append(Token('DIV','/',self.line))
                elif op == '=': tokens.append(Token('ASSIGN','=',self.line))
                elif op == '.': tokens.append(Token('DOT','.',self.line))
                elif op == '[': tokens.append(Token('LBRACKET','[',self.line))
                elif op == ']': tokens.append(Token('RBRACKET',']',self.line))
                elif op == ',': tokens.append(Token('COMMA',',',self.line))
                continue

            # Parentheses
            if ch == '(': tokens.append(Token('LPAREN','(',self.line)); self.advance(); continue
            if ch == ')': tokens.append(Token('RPAREN',')',self.line)); self.advance(); continue

            # Newline
            if ch == '\n': self.line += 1; self.advance(); tokens.append(Token('NEWLINE','\n',self.line)); continue

            raise SyntaxError(f"Unexpected character '{ch}' at line {self.line}")
        tokens.append(Token('EOF','EOF',self.line))
        return tokens

# ============================================================
# AST NODES (all classes kept for brevity - same as previous)
# ============================================================
class ASTNode: pass
class Program(ASTNode):
    def __init__(self, stmts):
        self.statements = stmts
class Say(ASTNode):
    def __init__(self, e):
        self.expr = e
class Show(ASTNode):
    def __init__(self, e):
        self.expr = e
class Assign(ASTNode):
    def __init__(self, n, e):
        self.name = n
        self.expr = e
class Ask(ASTNode):
    def __init__(self, p):
        self.prompt = p
class IfThenElse(ASTNode):
    def __init__(self, c, t, e=None):
        self.condition=c
        self.then_block=t
        self.else_block=e
class Repeat(ASTNode):
    def __init__(self, t, b):
        self.times_expr=t
        self.block=b
class While(ASTNode):
    def __init__(self, c, b):
        self.condition=c
        self.block=b
class ForRange(ASTNode):
    def __init__(self, v, s, e, st, b):
        self.var_name=v
        self.start=s
        self.end=e
        self.step=st
        self.block=b
class ForEach(ASTNode):
    def __init__(self, v, c, i, b):
        self.var_name=v
        self.collection=c
        self.index_var=i
        self.block=b
class BinaryOp(ASTNode):
    def __init__(self, l, o, r):
        self.left=l
        self.op=o
        self.right=r
class NotExpr(ASTNode):
    def __init__(self, e):
        self.expr=e
class RandomBetween(ASTNode):
    def __init__(self, l, h):
        self.low=l
        self.high=h
class Variable(ASTNode):
    def __init__(self, n):
        self.name=n
class Literal(ASTNode):
    def __init__(self, v):
        self.value=v
class Stop(ASTNode):
    def __init__(self, e=False):
        self.everything=e
class Flash(ASTNode):
    def __init__(self, e):
        self.expr=e
class Alert(ASTNode):
    def __init__(self, e):
        self.expr=e
class Error(ASTNode):
    def __init__(self, e):
        self.expr=e
class Warning(ASTNode):
    def __init__(self, e):
        self.expr=e
class Confirm(ASTNode):
    def __init__(self, p):
        self.prompt_expr=p
class Prompt(ASTNode):
    def __init__(self, p):
        self.prompt_expr=p
class FunctionDef(ASTNode):
    def __init__(self, n, p, b, s=False, sp=None):
        self.name=n
        self.params=p
        self.body=b
        self.has_star_args=s
        self.star_param=sp
class Loop(ASTNode):
    def __init__(self, b):
        self.block=b
class FunctionCall(ASTNode):
    def __init__(self, n, a):
        self.name=n
        self.args=a
class Return(ASTNode):
    def __init__(self, e=None):
        self.expr=e
class ModuleImport(ASTNode):
    def __init__(self, m):
        self.module_name=m
class RichCollectionLiteral(ASTNode):
    def __init__(self, e):
        self.elements=e
class IndexAccess(ASTNode):
    def __init__(self, c, i):
        self.collection=c
        self.index=i
class Assert(ASTNode):
    def __init__(ass):
        self.assertion = ass
# ============================================================
# PARSER
# ============================================================
class Parser:
    def __init__(self, tokens): self.tokens = tokens; self.pos = 0
    def peek(self): return self.tokens[self.pos] if self.pos < len(self.tokens) else Token('EOF','EOF',-1)
    def consume(self, expected_type=None):
        t = self.peek()
        if expected_type and t.type != expected_type:
            raise SyntaxError(f"Expected {expected_type} but got {t.type} ({t.value}) at line {t.line}")
        self.pos += 1; return t

    def parse_program(self):
        stmts = []
        while self.peek().type == 'NEWLINE': self.pos += 1
        while self.peek().type != 'EOF':
            s = self.parse_statement()
            if s: stmts.append(s)
            while self.peek().type == 'NEWLINE': self.consume('NEWLINE')
        return Program(stmts)

    def parse_statement(self):
        t = self.peek()
        if t.type in ('EOF','NEWLINE'): return None
        if t.type in ('SET','LET'): return self.parse_assign()
        if t.type == 'SAY': self.consume('SAY'); return Say(self.parse_expression())
        if t.type == 'SHOW': self.consume('SHOW'); return Show(self.parse_expression())
        if t.type == 'FLASH': self.consume('FLASH'); return Flash(self.parse_expression())
        if t.type == 'ALERT': self.consume('ALERT'); return Alert(self.parse_expression())
        if t.type == 'ERROR': self.consume('ERROR'); return Error(self.parse_expression())
        if t.type == 'WARNING': self.consume('WARNING'); return Warning(self.parse_expression())
        if t.type == 'ASSERT': self.consume('ASSERT'); return Assert(self.parse_expression())
        if t.type == 'IF':
            self.consume('IF'); c = self.parse_expression(); self.consume('THEN')
            tb = self.parse_block(); eb = None
            if self.peek().type == 'ELSE': self.consume('ELSE'); eb = self.parse_block()
            self.consume('END'); return IfThenElse(c, tb, eb)
        if t.type == 'REPEAT':
            self.consume('REPEAT'); te = self.parse_expression(); self.consume('TIMES')
            b = self.parse_block(); self.consume('END'); return Repeat(te, b)
        if t.type == 'WHILE':
            self.consume('WHILE'); c = self.parse_expression(); self.consume('DO')
            b = self.parse_block(); self.consume('END'); return While(c, b)
        if t.type == 'LOOP': self.consume('LOOP'); b = self.parse_block(); self.consume('END'); return Loop(b)
        if t.type == 'FOR':
            self.consume('FOR')
            if self.peek().type == 'EACH': return self.parse_for_each()
            else: return self.parse_for_range()
        if t.type == 'LEARN': return self.parse_function_def()
        if t.type == 'RETURN':
            self.consume('RETURN'); e = None
            if self.peek().type not in ('NEWLINE','EOF'): e = self.parse_expression()
            return Return(e)
        if t.type == 'STOP':
            self.consume('STOP'); ev = False
            if self.peek().type == 'EVERYTHING': ev = True; self.consume('EVERYTHING')
            return Stop(ev)
        if t.type == 'MODULE': self.consume('MODULE'); return ModuleImport(self.consume('STRING').value)
        if t.type == 'IDENTIFIER' and self.pos+1 < len(self.tokens) and self.tokens[self.pos+1].type == 'LPAREN':
            n = self.consume('IDENTIFIER').value; self.consume('LPAREN')
            args = []
            if self.peek().type != 'RPAREN':
                args.append(self.parse_expression())
                while self.peek().type == 'COMMA': self.consume('COMMA'); args.append(self.parse_expression())
            self.consume('RPAREN'); return FunctionCall(n, args)
        raise SyntaxError(f"Unexpected token {t.type} ({t.value}) at line {t.line}")

    def parse_assign(self):
        self.consume(self.peek().type); var = self.consume('IDENTIFIER').value
        if self.peek().type == 'PLUSEQ': self.consume('PLUSEQ'); return Assign(var, BinaryOp(Variable(var),'PLUS',self.parse_expression()))
        if self.peek().type == 'MINUSEQ': self.consume('MINUSEQ'); return Assign(var, BinaryOp(Variable(var),'MINUS',self.parse_expression()))
        if self.peek().type == 'MULEQ': self.consume('MULEQ'); return Assign(var, BinaryOp(Variable(var),'MUL',self.parse_expression()))
        if self.peek().type == 'DIVEQ': self.consume('DIVEQ'); return Assign(var, BinaryOp(Variable(var),'DIV',self.parse_expression()))
        self.consume('ASSIGN')
        if self.peek().type == 'ASK': self.consume('ASK'); return Assign(var, Ask(self.parse_expression()))
        return Assign(var, self.parse_expression())

    def parse_for_range(self):
        v = self.consume('IDENTIFIER').value; self.consume('ASSIGN')
        s = self.parse_expression(); self.consume('TO'); e = self.parse_expression()
        st = Literal(1)
        if self.peek().type == 'STEP': self.consume('STEP'); st = self.parse_expression()
        self.consume('DO'); b = self.parse_block(); self.consume('END')
        return ForRange(v, s, e, st, b)
    

    def parse_for_each(self):
        self.consume('EACH'); v = self.consume('IDENTIFIER').value; iv = None
        if self.peek().type == 'AT': self.consume('AT'); iv = self.consume('IDENTIFIER').value
        self.consume('IN'); c = self.parse_expression(); self.consume('DO')
        b = self.parse_block(); self.consume('END')
        return ForEach(v, c, iv, b)

    def parse_function_def(self):
        self.consume('LEARN'); self.consume('TO'); n = self.consume('IDENTIFIER').value
        self.consume('LPAREN'); params = []; hs = False; sp = None
        if self.peek().type != 'RPAREN':
            if self.peek().type == 'MUL': self.consume('MUL'); sp = self.consume('IDENTIFIER').value; hs = True
            else:
                params.append(self.consume('IDENTIFIER').value)
                while self.peek().type == 'COMMA':
                    self.consume('COMMA')
                    if self.peek().type == 'MUL': self.consume('MUL'); sp = self.consume('IDENTIFIER').value; hs = True; break
                    params.append(self.consume('IDENTIFIER').value)
        self.consume('RPAREN')
        while self.peek().type == 'NEWLINE': self.consume('NEWLINE')
        b = self.parse_block(); self.consume('END')
        return FunctionDef(n, params, b, hs, sp)

    def parse_block(self):
        stmts = []
        while self.peek().type not in ('END','ELSE','EOF'):
            if self.peek().type == 'NEWLINE': self.consume('NEWLINE'); continue
            s = self.parse_statement()
            if s: stmts.append(s)
        return stmts

    def parse_expression(self): return self.parse_comparison()
    def parse_comparison(self):
        l = self.parse_arithmetic()
        while self.peek().type in ('LT','GT','LTEQ','GTEQ','EQEQ','NOTEQ'):
            op = self.consume().type; r = self.parse_arithmetic(); l = BinaryOp(l, op, r)
        return l
    def parse_arithmetic(self):
        l = self.parse_term()
        while self.peek().type in ('PLUS','MINUS'): op = self.consume().type; r = self.parse_term(); l = BinaryOp(l, op, r)
        return l
    def parse_term(self):
        l = self.parse_unary()
        while self.peek().type in ('MUL','DIV'): op = self.consume().type; r = self.parse_unary(); l = BinaryOp(l, op, r)
        return l
    def parse_unary(self):
        if self.peek().type == 'MINUS': self.consume('MINUS'); return BinaryOp(Literal(0),'MINUS',self.parse_unary())
        if self.peek().type == 'NOT': self.consume('NOT'); return NotExpr(self.parse_unary())
        return self.parse_postfix()
    def parse_postfix(self):
        e = self.parse_atom()
        while self.peek().type == 'LBRACKET':
            self.consume('LBRACKET'); i = self.parse_expression(); self.consume('RBRACKET'); e = IndexAccess(e, i)
        return e
    def parse_atom(self):
        t = self.peek()
        if t.type == 'NUMBER': self.consume(); return Literal(t.value)
        if t.type == 'STRING': self.consume(); return Literal(t.value)
        if t.type == 'BOOLEAN': self.consume(); return Literal(t.value)
        if t.type == 'IDENTIFIER':
            n = self.consume('IDENTIFIER').value
            if self.peek().type == 'DOT': self.consume('DOT'); n = n + "." + self.consume('IDENTIFIER').value
            if self.peek().type == 'LPAREN':
                self.consume('LPAREN'); args = []
                if self.peek().type != 'RPAREN':
                    args.append(self.parse_expression())
                    while self.peek().type == 'COMMA': self.consume('COMMA'); args.append(self.parse_expression())
                self.consume('RPAREN'); return FunctionCall(n, args)
            return Variable(n)
        if t.type == 'LPAREN': self.consume(); e = self.parse_expression(); self.consume('RPAREN'); return e
        if t.type == 'LBRACKET':
            self.consume('LBRACKET'); el = []
            if self.peek().type != 'RBRACKET':
                el.append(self.parse_expression())
                while self.peek().type == 'COMMA': self.consume('COMMA'); el.append(self.parse_expression())
            self.consume('RBRACKET'); return RichCollectionLiteral(el)
        if t.type == 'RANDOM':
            self.consume(); self.consume('NUMBERTYPE'); self.consume('BETWEEN')
            l = self.parse_expression(); self.consume('AND'); h = self.parse_expression()
            return RandomBetween(l, h)
        if t.type == 'CONFIRM': self.consume('CONFIRM'); return Confirm(self.parse_expression())
        if t.type == 'PROMPT': self.consume('PROMPT'); return Prompt(self.parse_expression())
        raise SyntaxError(f"Unexpected token in expression: {t.type} ({t.value}) at line {t.line}")

# ============================================================
# RICH COLLECTION
# ============================================================
class RichCollection:
    def __init__(self, items=None): self._items = list(items) if items else []
    def length(self): return len(self._items)
    def sort(self): return RichCollection(sorted(self._items, key=lambda x: str(x)))
    def reverse(self): return RichCollection(list(reversed(self._items)))
    def contains(self, item): return item in self._items
    def indexOf(self, item):
        try: return self._items.index(item)
        except ValueError: return -1
    def isEmpty(self): return len(self._items) == 0
    def __getitem__(self, i):
        if i < 0: i = len(self._items) + i
        return self._items[i]
    def __setitem__(self, i, v):
        if i < 0: i = len(self._items) + i
        self._items[i] = v
    def __add__(self, o):
        if isinstance(o, RichCollection): return RichCollection(self._items + o._items)
        return RichCollection(self._items + [o])
    def __str__(self): return "[" + ", ".join(str(x) for x in self._items) + "]"
    def __iter__(self): return iter(self._items)
    def __len__(self): return len(self._items)

# ============================================================
# EXCEPTIONS
# ============================================================
class ReturnStop(Exception):
    def __init__(self, everything=False): self.everything = everything
class ReturnValue(Exception):
    def __init__(self, value): self.value = value

# ============================================================
# RICHY MODULE
# ============================================================
class RichyModule:
    def __init__(self, name): self.name = name; self._functions = {}; self._variables = {}
    def register(self, n, f): self._functions[n] = f
    def set_variable(self, n, v): self._variables[n] = v
    def get(self, n):
        if n in self._variables: return self._variables[n]
        if n in self._functions: return self._functions[n]
        raise NameError(f"'{n}' not found in module '{self.name}'")
    def call(self, interpreter, n, args):
        if n not in self._functions: raise NameError(f"Module '{self.name}' has no function '{n}'")
        return self._functions[n](*args)

# ============================================================
# INTERPRETER
# ============================================================
class Interpreter:
    def __init__(self, callbacks=None):
        self.variables = {}; self.functions = {}; self.modules = {}; self.running = True
        self._loaded_modules = set(); self._loading_stack = []
        c = callbacks or {}
        self.output = c.get('output', print)
        self.input = c.get('input', lambda p: input(p+" "))
        self.flash = c.get('flash', lambda m: print(f"[FLASH] {m}"))
        self.alert = c.get('alert', lambda m: print(f"[ALERT] {m}"))
        self.error = c.get('error', lambda m: print(f"[ERROR] {m}"))
        self.warning = c.get('warning', lambda m: print(f"[WARNING] {m}"))
        self.confirm = c.get('confirm', lambda m: input(m+" (y/n) ").lower().startswith('y'))
        self.prompt = c.get('prompt', lambda m: input(m+" "))
        self.module_loader = c.get('module_loader', None)

    def register_module(self, n, m): self.modules[n] = m

    def eval(self, node, local_vars=None):
        if local_vars is None: local_vars = self.variables
        if isinstance(node, Program):
            for s in node.statements:
                try: self.eval(s, local_vars)
                except ReturnStop as stop:
                    if stop.everything: self.running = False; break
        elif isinstance(node, Say): self.output(str(self.eval(node.expr, local_vars)))
        elif isinstance(node, Show): self.output(str(self.eval(node.expr, local_vars)))
        elif isinstance(node, Assign): local_vars[node.name] = self.eval(node.expr, local_vars)
        elif isinstance(node, Ask):
            p = str(self.eval(node.prompt, local_vars)); r = self.input(p)
            try: return float(r)
            except ValueError: return r
        elif isinstance(node, Flash): self.flash(str(self.eval(node.expr, local_vars)))
        elif isinstance(node, Alert): self.alert(str(self.eval(node.expr, local_vars)))
        elif isinstance(node, Error): self.error(str(self.eval(node.expr, local_vars)))
        elif isinstance(node, Warning): self.warning(str(self.eval(node.expr, local_vars)))
        elif isinstance(node, Confirm): return self.confirm(str(self.eval(node.prompt_expr, local_vars)))
        elif isinstance(node, Prompt):
            r = self.prompt(str(self.eval(node.prompt_expr, local_vars)))
            if r is None: return ""
            try: return float(r)
            except ValueError: return r
        elif isinstance(node, IfThenElse):
            if self.eval(node.condition, local_vars):
                for s in node.then_block: self.eval(s, local_vars)
            elif node.else_block:
                for s in node.else_block: self.eval(s, local_vars)
        elif isinstance(node, Repeat):
            for _ in range(int(self.eval(node.times_expr, local_vars))):
                for s in node.block: self.eval(s, local_vars)
        elif isinstance(node, While):
            while self.eval(node.condition, local_vars):
                for s in node.block: self.eval(s, local_vars)
        elif isinstance(node, Loop):
            while True:
                for s in node.block: self.eval(s, local_vars)
        elif isinstance(node, ForRange):
            start = int(self.eval(node.start, local_vars))
            end = int(self.eval(node.end, local_vars))
            step = int(self.eval(node.step, local_vars))
            for i in range(start, end+1, step):
                local_vars[node.var_name] = i
                for s in node.block: self.eval(s, local_vars)
        elif isinstance(node, ForEach):
            col = self.eval(node.collection, local_vars)
            if isinstance(col, RichCollection):
                for idx, item in enumerate(col):
                    local_vars[node.var_name] = item
                    if node.index_var: local_vars[node.index_var] = idx
                    for s in node.block: self.eval(s, local_vars)
        elif isinstance(node, FunctionDef): self.functions[node.name] = node
        elif isinstance(node, FunctionCall):
            args = [self.eval(a, local_vars) for a in node.args]
            if "." in node.name:
                p = node.name.split("."); mn = p[0]; fn = p[-1]
                if mn in self.modules: return self.modules[mn].call(self, fn, args)
                raise NameError(f"Module '{mn}' not found")
            if node.name in self.functions:
                fd = self.functions[node.name]; nv = {}
                if fd.has_star_args:
                    nc = len(fd.params); na = args[:nc]; sa = args[nc:]
                    for pp, aa in zip(fd.params, na): nv[pp] = aa
                    nv[fd.star_param] = RichCollection(sa)
                else:
                    for pp, aa in zip(fd.params, args): nv[pp] = aa
                try:
                    for s in fd.body: self.eval(s, nv)
                except ReturnValue as ret: return ret.value
                return None
            if node.name in self.modules: return self.modules[node.name].call(self, node.name, args)
            raise NameError(f"Function '{node.name}' not defined")
        elif isinstance(node, Return):
            v = None
            if node.expr is not None: v = self.eval(node.expr, local_vars)
            raise ReturnValue(v)
        elif isinstance(node, BinaryOp):
            l = self.eval(node.left, local_vars); r = self.eval(node.right, local_vars)
            if node.op == 'PLUS':
                if isinstance(l, str) or isinstance(r, str): return str(l) + str(r)
                if isinstance(l, RichCollection) and isinstance(r, RichCollection): return l + r
                return l + r
            elif node.op == 'MINUS': return l - r
            elif node.op == 'MUL': return l * r
            elif node.op == 'DIV': return l / r
            elif node.op == 'LT': return l < r
            elif node.op == 'GT': return l > r
            elif node.op == 'LTEQ': return l <= r
            elif node.op == 'GTEQ': return l >= r
            elif node.op == 'EQEQ': return l == r
            elif node.op == 'NOTEQ': return l != r
        elif isinstance(node, NotExpr): return not self.eval(node.expr, local_vars)
        elif isinstance(node, RandomBetween):
            return random.randint(int(self.eval(node.low, local_vars)), int(self.eval(node.high, local_vars)))
        elif isinstance(node, Variable):
            if node.name in local_vars: return local_vars[node.name]
            if node.name in self.variables: return self.variables[node.name]
            raise NameError(f"Variable '{node.name}' not defined")
        elif isinstance(node, Literal): return node.value
        elif isinstance(node, Stop): raise ReturnStop(everything=node.everything)
        elif isinstance(node, RichCollectionLiteral):
            return RichCollection([self.eval(e, local_vars) for e in node.elements])
        elif isinstance(node, IndexAccess):
            col = self.eval(node.collection, local_vars)
            idx = int(self.eval(node.index, local_vars))
            if isinstance(col, RichCollection): return col[idx]
            raise RuntimeError("Cannot index non-collection")
        elif isinstance(node, ModuleImport):
            if self.module_loader: self.module_loader(node.module_name, self)
        else: raise RuntimeError(f"Unknown node: {type(node)}")

    def run(self, code):
        self.running = True
        try:
            if isinstance(code, Program): self.eval(code)
            elif isinstance(code, str):
                lexer = Lexer(code); tokens = lexer.tokenize()
                parser = Parser(tokens); program = parser.parse_program()
                self.eval(program)
            else: raise TypeError("Expected Program or string")
        except ReturnStop: pass
# ============================================================
# CONSTANTS
# ============================================================
DARK_THEME = """
    QMainWindow { background-color: #1e1e1e; }
    QTabWidget::pane { background-color: #1e1e1e; border: 1px solid #333; }
    QTabBar::tab {
        background-color: #2d2d2d; color: #cccccc; padding: 8px 15px;
        border-top-left-radius: 4px; border-top-right-radius: 4px;
    }
    QTabBar::tab:selected { background-color: #1e1e1e; color: #ffffff; }
    QTabBar::close-button { image: none; }
    QTabBar::close-button:hover { background: #e81123; }
    QToolBar { background-color: #333333; border: none; spacing: 5px; padding: 5px; }
    QPushButton {
        background-color: #0e639c; color: white; padding: 8px 16px;
        border-radius: 4px; font-weight: bold; border: none;
    }
    QPushButton:hover { background-color: #1177bb; }
    QPushButton#runBtn { background-color: #4CAF50; }
    QPushButton#runBtn:hover { background-color: #66BB6A; }
    QPushButton#clearBtn { background-color: #FF9800; }
    QPushButton#clearBtn:hover { background-color: #FFB74D; }
    QPushButton#stopBtn { background-color: #f44336; }
    QPushButton#stopBtn:hover { background-color: #ef5350; }
    QStatusBar { background-color: #007acc; color: white; font-weight: bold; }
    QSplitter::handle { background-color: #454545; width: 2px; }
    QMenuBar { background-color: #333333; color: #cccccc; }
    QMenuBar::item:selected { background-color: #0e639c; }
    QMenu { background-color: #252526; color: #cccccc; border: 1px solid #454545; }
    QMenu::item:selected { background-color: #0e639c; }
    QLabel { color: #cccccc; }
"""

# ============================================================
# LINE NUMBER AREA
# ============================================================
class LineNumberArea(QWidget):
    def __init__(self, editor):
        super().__init__(editor)
        self.editor = editor

    def sizeHint(self):
        return QSize(self.editor.line_number_area_width(), 0)

    def paintEvent(self, event):
        self.editor.line_number_area_paint(event)


# ============================================================
# CODE EDITOR
# ============================================================
class CodeEditor(QPlainTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.line_number_area = LineNumberArea(self)
        self.filepath = None
        
        self.blockCountChanged.connect(self.update_line_number_area_width)
        self.updateRequest.connect(self.update_line_number_area)
        self.cursorPositionChanged.connect(self.highlight_current_line)
        
        self.update_line_number_area_width(0)
        self.highlight_current_line()
        
        self.setFont(QFont("Consolas", 13))
        self.setStyleSheet("""
            QPlainTextEdit {
                background-color: #1e1e1e;
                color: #d4d4d4;
                border: none;
                padding: 10px;
                selection-background-color: #264f78;
                border-radius:8px;
            }
        """)
        self.setTabStopDistance(40)
        self.setLineWrapMode(QPlainTextEdit.NoWrap)

    def line_number_area_width(self):
        digits = len(str(max(1, self.blockCount())))
        space = 10 + self.fontMetrics().horizontalAdvance('9') * digits
        return space

    def update_line_number_area_width(self, _):
        self.setViewportMargins(self.line_number_area_width(), 0, 0, 0)

    def update_line_number_area(self, rect, dy):
        if dy:
            self.line_number_area.scroll(0, dy)
        else:
            self.line_number_area.update(
                0, rect.y(), self.line_number_area.width(), rect.height()
            )
        if rect.contains(self.viewport().rect()):
            self.update_line_number_area_width(0)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        cr = self.contentsRect()
        self.line_number_area.setGeometry(
            QRect(cr.left(), cr.top(), self.line_number_area_width(), cr.height())
        )

    def highlight_current_line(self):
        extra_selections = []
        if not self.isReadOnly():
            selection = QTextEdit.ExtraSelection()
            line_color = QColor("#2a2a2a")
            selection.format.setBackground(line_color)
            selection.format.setProperty(QTextFormat.FullWidthSelection, True)
            selection.cursor = self.textCursor()
            selection.cursor.clearSelection()
            extra_selections.append(selection)
        self.setExtraSelections(extra_selections)

    def line_number_area_paint(self, event):
        painter = QPainter(self.line_number_area)
        painter.fillRect(event.rect(), QColor("#252526"))
        
        block = self.firstVisibleBlock()
        block_number = block.blockNumber()
        top = self.blockBoundingGeometry(block).translated(self.contentOffset()).top()
        bottom = top + self.blockBoundingRect(block).height()
        current_line = self.textCursor().blockNumber()

        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                number = str(block_number + 1)
                if block_number == current_line:
                    painter.setPen(QColor("#ffffff"))
                    painter.setFont(QFont("Consolas", 12, QFont.Bold))
                else:
                    painter.setPen(QColor("#858585"))
                    painter.setFont(QFont("Consolas", 11))
                painter.drawText(
                    0, int(top), self.line_number_area.width() - 5,
                    self.fontMetrics().height(), Qt.AlignRight, number
                )
            block = block.next()
            top = bottom
            bottom = top + self.blockBoundingRect(block).height()
            block_number += 1


# ============================================================
# SYNTAX HIGHLIGHTER
# ============================================================
class RichyHighlighter(QSyntaxHighlighter):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.rules = []
        self.filepath = None

        # Keywords
        kw_fmt = QTextCharFormat()
        kw_fmt.setForeground(QColor("#569CD6"))
        kw_fmt.setFontWeight(QFont.Bold)
        keywords = [
            'set', 'let', 'say', 'ask', 'if', 'then', 'else', 'end',
            'repeat', 'times', 'while', 'do', 'for', 'each', 'in', 'to', 'step',
            'loop', 'learn', 'return', 'stop', 'everything', 'module',
            'random', 'number', 'between', 'and', 'true', 'false', 'not',
            'flash', 'alert', 'error', 'warning', 'confirm', 'prompt', 'import'
        ]
        for kw in keywords:
            self.rules.append((f"\\b{kw}\\b", kw_fmt))

        # Strings
        str_fmt = QTextCharFormat()
        str_fmt.setForeground(QColor("green"))
        self.rules.append(('"[^"]*"', str_fmt))

        # Single-line comments
        com_fmt = QTextCharFormat()
        com_fmt.setForeground(QColor("grey"))
        com_fmt.setFontItalic(True)
        self.rules.append(('--[^\n]*', com_fmt))

        # Multi-line comments
        mcom_fmt = QTextCharFormat()
        mcom_fmt.setForeground(QColor("grey"))
        mcom_fmt.setFontItalic(True)

        # Numbers
        num_fmt = QTextCharFormat()
        num_fmt.setForeground(QColor("yellow"))
        self.rules.append(('\\b\\d+(\\.\\d+)?\\b', num_fmt))

        # Functions
        func_fmt = QTextCharFormat()
        func_fmt.setForeground(QColor("blue"))
        self.rules.append(('\\b([a-zA-Z_][a-zA-Z0-9_]*)\\s*\\(', func_fmt))

        self.multi_line_comment_format = mcom_fmt

    def highlightBlock(self, text):
        # Appliquer les règles simples
        for pattern, fmt in self.rules:
            for match in re.finditer(pattern, text):
                start = match.start()
                length = match.end() - start
                self.setFormat(start, length, fmt)

        # Gestion spéciale des commentaires multilignes
        self.highlight_multiline_comments(text)

    def highlight_multiline_comments(self, text):
        start_index = 0
        if self.previousBlockState() == 1:
            start_index = 0
        else:
            start_index = text.find('/*')

        while start_index >= 0:
            end_index = text.find('*/', start_index + 2)
            if end_index >= 0:
                length = end_index - start_index + 2
                self.setFormat(start_index, length, self.multi_line_comment_format)
                start_index = text.find('/*', end_index + 2)
                self.setCurrentBlockState(0)
            else:
                self.setFormat(start_index, len(text) - start_index, self.multi_line_comment_format)
                self.setCurrentBlockState(1)
                break


# ============================================================
# CONSOLE OUTPUT
# ============================================================
class ConsoleWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.output = QTextEdit()
        self.output.setReadOnly(True)
        self.output.setFont(QFont("Consolas", 11))
        self.output.setStyleSheet(
            "background-color: #0d0d0d; color: #00ff00; padding: 10px; border: none;"
        )
        layout.addWidget(self.output)

        self.input_line = QLineEdit()
        self.input_line.setFont(QFont("Consolas", 11))
        self.input_line.setStyleSheet(
            "background-color: #1a1a1a; color: #00ff00; padding: 8px; "
            "border: 1px solid #333; border-top: 2px solid #007acc; border-radius: 6px;"
        )
        self.input_line.setPlaceholderText("Réponds ici... (Enter pour valider)")
        self.input_line.setEnabled(False)
        layout.addWidget(self.input_line)

    def write(self, text):
        self.output.append(str(text))

    def clear(self):
        self.output.clear()

    def read_line(self, callback):
        self.input_line.setEnabled(True)
        self.input_line.setFocus()
        self.input_line.returnPressed.connect(lambda: self._on_input(callback))

    def _on_input(self, callback):
        text = self.input_line.text()
        self.input_line.clear()
        self.input_line.setEnabled(False)
        callback(text)


# ============================================================
# MAIN WINDOW
# ============================================================
class RichyScriptIDE(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"RichyScript IDE v{__version__}")
        self.setGeometry(100, 100, 1300, 850)
        self.setStyleSheet(DARK_THEME)

        self.last_error = None
        self.current_file = None
        self._loaded_modules = set()
        self._input_callback = None
        self._is_running = False

        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.lib_dir = os.path.join(self.base_dir, "lib")
        self.rlib_dir = os.path.join(self.base_dir, "rlib")
        if not os.path.exists(self.rlib_dir):
            os.makedirs(self.rlib_dir)

        
        for d in [self.lib_dir, self.rlib_dir]:
            if not os.path.exists(d):
                os.makedirs(d)

        self.builtins = RichyModule("builtins")
        self._register_builtins()

        self.setup_ui()
        self.setup_menu()
        self.load_example()

    # ========== BUILTINS ==========
    def _register_builtins(self):
        b = self.builtins
        b.register("roll", lambda sides: random.randint(1, int(sides)))
        b.register("loot", lambda: random.choice(["gold", "potion", "sword", "shield"]))
        b.register("strlen", lambda s: len(str(s)))
        b.register("uppercase", lambda s: str(s).upper())
        b.register("lowercase", lambda s: str(s).lower())
        b.register("contains", lambda s, sub: sub in str(s))
        b.register("replace", lambda s, old, new: str(s).replace(old, new))
        b.register("trim", lambda s: str(s).strip())
        b.register("split", lambda s, sep: str(s).split(sep))
        b.register("join", lambda arr, sep: sep.join(str(x) for x in arr))
        b.register("sum", lambda arr: sum(arr._items if isinstance(arr, RichCollection) else arr))
        b.register("count", lambda arr: arr.length() if isinstance(arr, RichCollection) else len(arr))
        b.register("max", lambda arr: max(arr._items if isinstance(arr, RichCollection) else arr))
        b.register("min", lambda arr: min(arr._items if isinstance(arr, RichCollection) else arr))
        b.register("floor", lambda x: int(float(x)))
        b.register("ceil", lambda x: int(float(x)) + 1 if float(x) != int(float(x)) else int(float(x)))
        b.register("round", lambda x, d=0: round(float(x), int(d)))
        b.register("abs", lambda x: abs(float(x)))
        b.register("sqrt", lambda x: __import__('math').sqrt(float(x)))
        b.register("cos", lambda x: __import__('math').cos(float(x)))
        b.register("sin", lambda x: __import__('math').sin(float(x)))
        b.register("pi", lambda: __import__('math').pi)
        b.register("now", lambda: __import__('time').time())
        b.register("sleep", lambda ms: __import__('time').sleep(float(ms) / 1000))
        b.register("random_color", lambda: f"#{random.randint(0,255):02X}{random.randint(0,255):02X}{random.randint(0,255):02X}")

    # ========== UI SETUP ==========
    def setup_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Toolbar
        toolbar = QToolBar()
        toolbar.setMovable(False)
        self.addToolBar(toolbar)

        buttons = [
            ("runBtn", "▶ Run (F5)", self.run_code, "#4CAF50"),
            ("", "📄 Example", self.load_example, "#2196F3"),
            ("clearBtn", "🧹 Clear", self.clear_output, "#FF9800"),
            ("", "❓ Why?", self.show_why, "#9C27B0"),
            ("", "📦 Load .rlib", self.load_rlib, "#00BCD4"),
            ("", "📂 Open", self.open_file, "#795548"),
            ("", "💾 Save", self.save_file, "#607D8B"),
            ("stopBtn", "⏹ Stop", self.stop_execution, "#f44336"),
        ]

        for obj_name, text, slot, color in buttons:
            btn = QPushButton(text)
            if obj_name:
                btn.setObjectName(obj_name)
            btn.setStyleSheet(f"background-color: {color};")
            btn.clicked.connect(slot)
            toolbar.addWidget(btn)

        toolbar.addSeparator()
        theme_btn = QPushButton("🌙 Theme")
        theme_btn.clicked.connect(self.toggle_theme)
        toolbar.addWidget(theme_btn)

        # Splitter
        splitter = QSplitter(Qt.Vertical)
        splitter.setHandleWidth(3)

        # Tabs
        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.new_tab()
        splitter.addWidget(self.tabs)

        # Console
        self.console = ConsoleWidget()
        self.console.input_line.returnPressed.connect(self.on_console_enter)
        splitter.addWidget(self.console)

        splitter.setSizes([550, 250])
        layout.addWidget(splitter)

        # Status bar
        self.status = QStatusBar()
        self.status.showMessage(f"RichyScript v{__version__} - Ready | lib/ + rlib/")
        self.setStatusBar(self.status)

        # Shortcuts
        QShortcut(QKeySequence("F5"), self, self.run_code)
        QShortcut(QKeySequence("Ctrl+S"), self, self.save_file)
        QShortcut(QKeySequence("Ctrl+O"), self, self.open_file)
        QShortcut(QKeySequence("Ctrl+N"), self, self.new_tab)
        QShortcut(QKeySequence("Ctrl+W"), self, lambda: self.close_tab(self.tabs.currentIndex()))

    def setup_menu(self):
        menubar = self.menuBar()

        file_menu = menubar.addMenu("&Fichier")
        file_menu.addAction("Nouveau (Ctrl+N)", self.new_tab)
        file_menu.addAction("Ouvrir (Ctrl+O)", self.open_file)
        file_menu.addAction("Sauvegarder (Ctrl+S)", self.save_file)
        file_menu.addSeparator()
        file_menu.addAction("Quitter (Alt+F4)", self.close)

        run_menu = menubar.addMenu("&Exécution")
        run_menu.addAction("Exécuter (F5)", self.run_code)
        run_menu.addAction("Arrêter", self.stop_execution)
        run_menu.addSeparator()
        run_menu.addAction("Charger .rlib", self.load_rlib)

        help_menu = menubar.addMenu("&Aide")
        help_menu.addAction("Pourquoi cette erreur ?", self.show_why)
        help_menu.addAction("À propos", self.show_about)

    # ========== TABS ==========
    def new_tab(self):
        editor = CodeEditor()
        RichyHighlighter(editor.document())
        index = self.tabs.addTab(editor, "Nouveau.richy")
        self.tabs.setCurrentIndex(index)
        return editor

    def close_tab(self, index):
        if self.tabs.count() > 1:
            self.tabs.removeTab(index)

    def current_editor(self):
        widget = self.tabs.currentWidget()
        return widget if isinstance(widget, CodeEditor) else None

    # ========== CONSOLE ==========
    def append_output(self, text):
        self.console.write(str(text))

    def clear_output(self):
        self.console.clear()

    def on_console_enter(self):
        if self._input_callback:
            text = self.console.input_line.text()
            self.console.input_line.clear()
            self.console.input_line.setEnabled(False)
            callback = self._input_callback
            self._input_callback = None
            callback(text)

    def ask_console(self, prompt):
        self.append_output(prompt)
        self.console.input_line.setEnabled(True)
        self.console.input_line.setFocus()
        
        result = None
        loop = QEventLoop()
        
        def callback(text):
            nonlocal result
            result = text
            loop.quit()
        
        self._input_callback = callback
        loop.exec_()
        
        try:
            return float(result) if result else ""
        except (ValueError, TypeError):
            return result if result else ""

    # ========== FILES ==========
    def save_file(self):
        editor = self.current_editor()
        if not editor:return

        path = editor.filepath
        if not path:
            path, _ = QFileDialog.getSaveFileName(
            self, "Sauvegarder", self.lib_dir,
            "RichyScript (*.richy);;Tous (*.*)"
        )
        if not path:
            return

        with open(path, "w", encoding="utf-8") as f:
            f.write(editor.toPlainText())

        editor.filepath = path
        self.tabs.setTabText(self.tabs.currentIndex(), os.path.basename(path))
        self.status.showMessage(f"💾 Sauvé : {path}")

    def open_file(self):
        path, _ = QFileDialog.getOpenFileName(
        self, "Ouvrir", self.lib_dir, "RichyScript (*.richy);;Tous (*.*)"
     )
        if not path:return

        with open(path, "r", encoding="utf-8") as f:
            code = f.read()

            editor = self.new_tab()
            editor.setPlainText(code)
            editor.filepath = path  # <-- associer le chemin
            self.tabs.setTabText(self.tabs.currentIndex(), os.path.basename(path))
            self.status.showMessage(f"📂 Ouvert : {path}")


    def import_richy_module(self, module_name, interpreter):
        """Importe un module .richy et charge automatiquement le .rlib associé."""
    # --- AUTO-CHARGEMENT DU .rlib CORRESPONDANT ---
        base_name = os.path.splitext(module_name)[0]   # ex: "crypto" à partir de "crypto.richy"
        rlib_filename = base_name + '.rlib'
    
    # Chercher dans rlib/ puis dans lib/
        for search_dir in (self.rlib_dir, self.lib_dir):
            rlib_path = os.path.join(search_dir, rlib_filename)
            if os.path.exists(rlib_path) and rlib_path not in self._loaded_modules:
                try:
                    with open(rlib_path, 'r', encoding='utf-8') as f:
                        rlib_code = f.read()
                
                # Vérifier les imports interdits
                    forbidden = ['import richyscript', 'from richyscript']
                    if any(pattern in rlib_code for pattern in forbidden):
                        raise RuntimeError(f"Le .rlib {rlib_filename} contient un import interdit.")
                
                    mod = RichyModule("user")
                    safe_namespace = {
                    'richy_function': lambda func: (mod.register(func.__name__, func), func)[1],
                    'random': __import__('random'),
                    'math': __import__('math'),
                    'time': __import__('time'),
                    'json': __import__('json'),
                    'os': __import__('os'),
                    'sys': __import__('sys'),
                    'platform': __import__('platform'),
                    're': __import__('re'),
                    'datetime': __import__('datetime'),
                    'collections': __import__('collections'),
                    }
                    exec(rlib_code, safe_namespace)
                    for fname, func in mod._functions.items():
                        self.builtins.register(fname, func)
                        self._loaded_modules.add(rlib_path)
                        self.append_output(f"📦 Chargement auto du .rlib : {rlib_filename}")
                        break
                except Exception as e:
                    self.append_output(f"⚠️ Erreur chargement {rlib_filename} : {e}")
    
    # --- CHARGEMENT DU .richy (comme avant) ---
        if module_name in interpreter._loaded_modules:
            return
        if module_name in interpreter._loading_stack:
            chain = "".join(interpreter._loading_stack + [module_name])
            raise RuntimeError(f"Import circulaire : {chain}")
    
        interpreter._loading_stack.append(module_name)
        try:
            module_path = os.path.join(self.lib_dir, module_name)
            if not os.path.exists(module_path):
                module_path = os.path.join(self.rlib_dir, module_name)  # fallback
            if not os.path.exists(module_path):
                raise FileNotFoundError(f"Module introuvable : {module_name}")
            with open(module_path, 'r', encoding='utf-8') as f:
                code = f.read()
                lexer = Lexer(code)
                tokens = lexer.tokenize()
                parser = Parser(tokens)
                program = parser.parse_program()
                count = 0
                for stmt in program.statements:
                    if isinstance(stmt, FunctionDef):
                        interpreter.functions[stmt.name] = stmt
                        count += 1
                        interpreter._loaded_modules.add(module_name)
                        self.status.showMessage(f"📦 {module_name} ({count} fonctions)")
        finally:
            interpreter._loading_stack.pop()


    def load_rlib(self):
        """Charge un module .rlib (Python) de façon sécurisée."""
        path, _ = QFileDialog.getOpenFileName(
            self, "Charger un module .rlib", 
            self.rlib_dir,
            "RichyScript Library (*.rlib);;Python (*.py);;Tous (*.*)"
        )
        if not path:
            return
        
        if path in self._loaded_modules:
            tkmb.showinfo("Info", "Ce module est déjà chargé.")
            return
        
        try:
            with open(path, "r", encoding="utf-8") as f:
                module_code = f.read()
            
            # Vérifier les imports interdits
            forbidden = ['import richyscript', 'from richyscript',
                          'import richyscript_ide', 'from richyscript_ide',
                          'import interpreter', 'from interpreter']
            for pattern in forbidden:
                if pattern in module_code:
                    tkmb.showerror("Erreur",
                        f"Import interdit : '{pattern}'\n"
                        "Les .rlib ne peuvent pas importer RichyScript.\n"
                        "Modules autorisés : random, math, time, json, os, re, etc."
                    )
                    return
            
            mod = RichyModule("user")
            
            safe_namespace = {
                'richy_function': lambda func: (mod.register(func.__name__, func), func)[1],
                'random': __import__('random'),
                'math': __import__('math'),
                'time': __import__('time'),
                'json': __import__('json'),
                'os': __import__('os'),
                'sys': __import__('sys'),
                'platform': __import__('platform'),
                're': __import__('re'),
                'datetime': __import__('datetime'),
                'collections': __import__('collections'),
                'itertools': __import__('itertools'),
                'functools': __import__('functools'),
                'hashlib': __import__('hashlib'),
                'base64': __import__('base64'),
                'csv': __import__('csv'),
                'uuid': __import__('uuid'),
            }
            
            exec(module_code, safe_namespace)
            
            count = 0
            for fname, func in mod._functions.items():
                self.builtins.register(fname, func)
                count += 1
            
            self._loaded_modules.add(path)
            
            if count > 0:
                tkmb.showinfo("Succès",
                    f"✅ {count} fonction(s) chargée(s)\n"
                    f"📄 {os.path.basename(path)}\n\n"
                    f"Utilisez : builtins.ma_fonction()"
                )
            else:
                tkmb.showwarning("Attention",
                    "Aucune fonction @richy_function trouvée.\n\n"
                    "Exemple correct :\n"
                    "@richy_function\n"
                    "def ma_fonction(x):\n"
                    "    return x * 2"
                )
                
        except RecursionError:
            tkmb.showerror("Erreur",
                "Récursion infinie !\n"
                "Votre module ne doit PAS importer RichyScript."
            )
        except Exception as e:
            tkmb.showerror("Erreur", str(e))

    # ========== EXAMPLE ==========
    def load_example(self):
        example = """/*
   RichyScript 2.0 Demo
   =====================
   Nouveautés v2.0 :
   - Listes [1, 2, 3]
   - Boucle for range + each
   - Opérateurs +=, -=, *=, /=
   - Fonctions *args
   - Commentaires /* */
*/

say "=== RichyScript 2.0 ==="
alert "Bienvenue dans RichyScript 2.0 !"

-- Listes
set fruits = ["pomme", "banane", "cerise", "kiwi"]
say "Liste : " + fruits
say "Premier : " + fruits[0]
say "Dernier : " + fruits[-1]

-- For each
say ""
say "--- For Each ---"
for each fruit in fruits do
    say "→ " + builtins.uppercase(fruit)
end

-- For range
say ""
say "--- For Range ---"
for i = 1 to 5 do
    say "Nombre " + i
end

-- For range with step
say ""
say "--- For Step ---"
for i = 0 to 20 step 5 do
    say "i = " + i
end

-- Opérateurs composés
say ""
say "--- Opérateurs composés ---"
set score = 0
set score += 10
say "Score +10 : " + score
set score *= 2
say "Score ×2 : " + score
set score -= 5
say "Score -5 : " + score
set score /= 3
say "Score /3 : " + builtins.round(score, 2)

-- Fonction avec *args
say ""
say "--- Fonction *args ---"
learn to moyenne(*nombres)
    set total = 0
    set count = 0
    for each n in nombres do
        set total += n
        set count += 1
    end
    if count = 0 then return 0 end
    return total / count
end

say "Moyenne de 10,20,30 : " + moyenne(10, 20, 30)
say "Moyenne de 5,10,15,20,25 : " + moyenne(5, 10, 15, 20, 25)

say ""
say "✅ Démo terminée !"
"""
        editor = self.current_editor()
        if editor:
            editor.setPlainText(example)
        self.status.showMessage("📄 Exemple 2.0 chargé | F5 pour exécuter")

    # ========== EXECUTION ==========
    def run_code(self):
        if self._is_running:
            return
        
        editor = self.current_editor()
        if not editor:
            return

        self.clear_output()
        self.status.showMessage("⚡ Exécution...")
        self.last_error = None
        self._is_running = True
        code = editor.toPlainText()

        try:
            lexer = Lexer(code)
            tokens = lexer.tokenize()
            parser = Parser(tokens)
            program = parser.parse_program()

            callbacks = {
                'output': self.append_output,
                'input': self.ask_console,
                'flash': lambda m: tkmb.showinfo("Flash", str(m)),
                'alert': lambda m: tkmb.showinfo("ℹ️ Alert", str(m)),
                'error': lambda m: tkmb.showerror("❌ Error", str(m)),
                'warning': lambda m: tkmb.showwarning("⚠️ Warning", str(m)),
                'confirm': lambda m: tkmb.askyesno("❓ Confirm", str(m)),
                'prompt': lambda m: tksd.askstring("📝 Prompt", str(m)) or "",
                'module_loader': lambda n, i: self.import_richy_module(n, i),
            }

            interpreter = Interpreter(callbacks)
            interpreter.register_module("builtins", self.builtins)
            interpreter.run(program)
            self.status.showMessage("✅ Exécution terminée")
            
        except SyntaxError as e:
            self.last_error = str(e)
            self.append_output(f"❌ Erreur de syntaxe : {e}")
            self.status.showMessage("❌ Erreur de syntaxe")
        except ReturnStop:
            self.status.showMessage("⏹ Exécution arrêtée")
        except Exception as e:
            self.last_error = str(e)
            self.append_output(f"❌ Erreur : {e}")
            self.status.showMessage("❌ Erreur d'exécution")
        finally:
            self._is_running = False

    def stop_execution(self):
        if self._is_running:
            self._is_running = False
            self.status.showMessage("⏹ Arrêt demandé...")

    # ========== WHY? ==========
    def show_why(self):
        if self.last_error:
            tkmb.showinfo("❓ Why?", self.last_error)
        else:
            tkmb.showinfo("❓ Why?", "Tout va bien ! Aucune erreur à expliquer.")

    def show_about(self):
        tkmb.showinfo("À propos",
            f"RichyScript IDE v{__version__}\n\n"
            "Un langage de programmation moderne pour apprendre à coder.\n\n"
            "Fonctionnalités :\n"
            "• Listes, boucles for, *args\n"
            "• Modules .richy et .rlib\n"
            "• IDE avec thème sombre\n"
            "• Numérotation des lignes\n"
            "• Mini-débogueur intégré"
        )

    # ========== THEME ==========
    def toggle_theme(self):
        if self.styleSheet() == DARK_THEME:
            self.setStyleSheet("")
            self.status.showMessage("☀️ Thème clair")
        else:
            self.setStyleSheet(DARK_THEME)
            self.status.showMessage("🌙 Thème sombre")


# ============================================================
# MAIN
# ============================================================
def main():
    app = QApplication(sys.argv)
    app.setApplicationName("RichyScript IDE")
    app.setApplicationVersion(__version__)
    
    # Style global
    app.setStyle("Fusion")
    
    ide = RichyScriptIDE()
    ide.show()
    
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()

